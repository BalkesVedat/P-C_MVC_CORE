﻿using System;
using System.Collections.Generic;

namespace AdminPanel.Models;

public partial class Birimler
{
    public int BirimId { get; set; }

    public string BirimAd { get; set; } = null!;

    public virtual ICollection<Urunler> Urunlers { get; set; } = new List<Urunler>();
}
