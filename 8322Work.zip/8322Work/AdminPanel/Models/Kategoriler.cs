﻿using System;
using System.Collections.Generic;

namespace AdminPanel.Models;

public partial class Kategoriler
{
    public int KategoriId { get; set; }

    public string KategoriAd { get; set; } = null!;

    public string? Aciklama { get; set; }

    public decimal? KdvOran { get; set; }

    public virtual ICollection<Urunler> Urunlers { get; set; } = new List<Urunler>();
}
