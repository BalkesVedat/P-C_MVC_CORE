﻿using System;
using System.Collections.Generic;

namespace AdminPanel.Models;

public partial class Sepetler
{
    public int SepetId { get; set; }

    public int MusteriId { get; set; }

    public int UrunId { get; set; }

    public decimal SepetBirimFiyati { get; set; }

    public decimal SepetUrunMiktari { get; set; }

    public DateTime? SepetTarihi { get; set; }

    public virtual Musteriler Musteri { get; set; } = null!;

    public virtual Urunler Urun { get; set; } = null!;
}
