﻿using System;
using System.Collections.Generic;

namespace AdminPanel.Models;

public partial class Resimler
{
    public int ResimId { get; set; }

    public int UrunId { get; set; }

    public string ResimYolu { get; set; } = null!;

    public string? ResimAciklamasi { get; set; }

    public virtual Urunler Urun { get; set; } = null!;
}
