﻿using System;
using System.Collections.Generic;

namespace AdminPanel.Models;

public partial class Satislar
{
    public int SatisId { get; set; }

    public DateTime? SatisTarihi { get; set; }

    public int? MusteriId { get; set; }

    public string? Durumu { get; set; }

    public DateTime? IslemTarihi { get; set; }

    public DateTime? TeslimTarihi { get; set; }

    public virtual Musteriler? Musteri { get; set; }

    public virtual ICollection<SatisDetaylari> SatisDetaylaris { get; set; } = new List<SatisDetaylari>();
}
