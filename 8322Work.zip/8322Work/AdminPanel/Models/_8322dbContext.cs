﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AdminPanel.Models;

public partial class _8322dbContext : DbContext
{
    public _8322dbContext()
    {
    }

    public _8322dbContext(DbContextOptions<_8322dbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Birimler> Birimlers { get; set; }

    public virtual DbSet<Kategoriler> Kategorilers { get; set; }

    public virtual DbSet<Musteriler> Musterilers { get; set; }

    public virtual DbSet<Resimler> Resimlers { get; set; }

    public virtual DbSet<Satinalmalar> Satinalmalars { get; set; }

    public virtual DbSet<SatisDetaylari> SatisDetaylaris { get; set; }

    public virtual DbSet<Satislar> Satislars { get; set; }

    public virtual DbSet<Sepetler> Sepetlers { get; set; }

    public virtual DbSet<Urunler> Urunlers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.;Database=8322DB;User ID=sa;Password=1;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Birimler>(entity =>
        {
            entity.HasKey(e => e.BirimId);

            entity.ToTable("Birimler");

            entity.Property(e => e.BirimId).HasColumnName("BirimID");
            entity.Property(e => e.BirimAd)
                .HasMaxLength(50)
                .HasColumnName("BirimAD");
        });

        modelBuilder.Entity<Kategoriler>(entity =>
        {
            entity.HasKey(e => e.KategoriId);

            entity.ToTable("Kategoriler");

            entity.Property(e => e.KategoriId).HasColumnName("KategoriID");
            entity.Property(e => e.KategoriAd)
                .HasMaxLength(50)
                .HasColumnName("KategoriAD");
            entity.Property(e => e.KdvOran).HasColumnType("decimal(3, 2)");
        });

        modelBuilder.Entity<Musteriler>(entity =>
        {
            entity.HasKey(e => e.MusteriId);

            entity.ToTable("Musteriler");

            entity.Property(e => e.MusteriId).HasColumnName("MusteriID");
            entity.Property(e => e.Adres).HasMaxLength(200);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MusteriAd)
                .HasMaxLength(50)
                .HasColumnName("MusteriAD");
            entity.Property(e => e.Telefon)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Resimler>(entity =>
        {
            entity.HasKey(e => e.ResimId);

            entity.ToTable("Resimler");

            entity.Property(e => e.ResimId).HasColumnName("ResimID");
            entity.Property(e => e.ResimAciklamasi).HasMaxLength(100);
            entity.Property(e => e.ResimYolu).HasMaxLength(500);
            entity.Property(e => e.UrunId).HasColumnName("UrunID");

            entity.HasOne(d => d.Urun).WithMany(p => p.Resimlers)
                .HasForeignKey(d => d.UrunId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Resimler_Urunler");
        });

        modelBuilder.Entity<Satinalmalar>(entity =>
        {
            entity.HasKey(e => e.SatinalmaId);

            entity.ToTable("Satinalmalar");

            entity.Property(e => e.SatinalmaId).HasColumnName("SatinalmaID");
            entity.Property(e => e.Aciklama).HasMaxLength(500);
            entity.Property(e => e.AlimBirimFiyati).HasColumnType("money");
            entity.Property(e => e.AlinanMiktar).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tutar).HasColumnType("money");
            entity.Property(e => e.UrunId).HasColumnName("UrunID");

            entity.HasOne(d => d.Urun).WithMany(p => p.Satinalmalars)
                .HasForeignKey(d => d.UrunId)
                .HasConstraintName("FK_Satinalmalar_Urunler");
        });

        modelBuilder.Entity<SatisDetaylari>(entity =>
        {
            entity.HasKey(e => e.SatisDetayId);

            entity.ToTable("SatisDetaylari");

            entity.Property(e => e.SatisDetayId).HasColumnName("SatisDetayID");
            entity.Property(e => e.SatilanMiktar).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SatisBirimFiyati).HasColumnType("money");
            entity.Property(e => e.SatisId).HasColumnName("SatisID");
            entity.Property(e => e.UrunId).HasColumnName("UrunID");

            entity.HasOne(d => d.Satis).WithMany(p => p.SatisDetaylaris)
                .HasForeignKey(d => d.SatisId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SatisDetaylari_Satislar");

            entity.HasOne(d => d.Urun).WithMany(p => p.SatisDetaylaris)
                .HasForeignKey(d => d.UrunId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SatisDetaylari_Urunler");
        });

        modelBuilder.Entity<Satislar>(entity =>
        {
            entity.HasKey(e => e.SatisId);

            entity.ToTable("Satislar");

            entity.Property(e => e.SatisId).HasColumnName("SatisID");
            entity.Property(e => e.Durumu).HasMaxLength(15);
            entity.Property(e => e.IslemTarihi).HasColumnType("smalldatetime");
            entity.Property(e => e.MusteriId).HasColumnName("MusteriID");
            entity.Property(e => e.SatisTarihi).HasColumnType("smalldatetime");
            entity.Property(e => e.TeslimTarihi).HasColumnType("smalldatetime");

            entity.HasOne(d => d.Musteri).WithMany(p => p.Satislars)
                .HasForeignKey(d => d.MusteriId)
                .HasConstraintName("FK_Satislar_Musteriler");
        });

        modelBuilder.Entity<Sepetler>(entity =>
        {
            entity.HasKey(e => e.SepetId);

            entity.ToTable("Sepetler");

            entity.Property(e => e.SepetId).HasColumnName("SepetID");
            entity.Property(e => e.MusteriId).HasColumnName("MusteriID");
            entity.Property(e => e.SepetBirimFiyati).HasColumnType("money");
            entity.Property(e => e.SepetTarihi).HasColumnType("smalldatetime");
            entity.Property(e => e.SepetUrunMiktari).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UrunId).HasColumnName("UrunID");

            entity.HasOne(d => d.Musteri).WithMany(p => p.Sepetlers)
                .HasForeignKey(d => d.MusteriId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Sepetler_Musteriler");

            entity.HasOne(d => d.Urun).WithMany(p => p.Sepetlers)
                .HasForeignKey(d => d.UrunId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Sepetler_Urunler");
        });

        modelBuilder.Entity<Urunler>(entity =>
        {
            entity.HasKey(e => e.UrunId);

            entity.ToTable("Urunler");

            entity.Property(e => e.UrunId).HasColumnName("UrunID");
            entity.Property(e => e.BirimFiyat).HasColumnType("money");
            entity.Property(e => e.BirimId).HasColumnName("BirimID");
            entity.Property(e => e.BirimMaliyet).HasColumnType("money");
            entity.Property(e => e.KategoriId).HasColumnName("KategoriID");
            entity.Property(e => e.UrunAd)
                .HasMaxLength(50)
                .HasColumnName("UrunAD");

            entity.HasOne(d => d.Birim).WithMany(p => p.Urunlers)
                .HasForeignKey(d => d.BirimId)
                .HasConstraintName("FK_Urunler_Birimler");

            entity.HasOne(d => d.Kategori).WithMany(p => p.Urunlers)
                .HasForeignKey(d => d.KategoriId)
                .HasConstraintName("FK_Urunler_Kategoriler");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
