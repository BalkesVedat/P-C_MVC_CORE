﻿using System;
using System.Collections.Generic;

namespace AdminPanel.Models;

public partial class Satinalmalar
{
    public int SatinalmaId { get; set; }

    public DateOnly? SatinalmaTarihi { get; set; }

    public int? UrunId { get; set; }

    public decimal? AlinanMiktar { get; set; }

    public decimal? AlimBirimFiyati { get; set; }

    public decimal? Tutar { get; set; }

    public string? Aciklama { get; set; }

    public virtual Urunler? Urun { get; set; }
}
