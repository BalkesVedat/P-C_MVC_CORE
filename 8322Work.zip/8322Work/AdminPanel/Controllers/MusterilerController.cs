﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminPanel.Models;

namespace AdminPanel.Controllers
{
    public class MusterilerController : Controller
    {
        private readonly _8322dbContext _context;

        public MusterilerController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: Musteriler
        public async Task<IActionResult> Index()
        {
            return View(await _context.Musterilers.ToListAsync());
        }

        // GET: Musteriler/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var musteriler = await _context.Musterilers
                .FirstOrDefaultAsync(m => m.MusteriId == id);
            if (musteriler == null)
            {
                return NotFound();
            }

            return View(musteriler);
        }

        // GET: Musteriler/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Musteriler/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MusteriId,MusteriAd,Email,Adres,Telefon")] Musteriler musteriler)
        {
            if (ModelState.IsValid)
            {
                _context.Add(musteriler);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(musteriler);
        }

        // GET: Musteriler/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var musteriler = await _context.Musterilers.FindAsync(id);
            if (musteriler == null)
            {
                return NotFound();
            }
            return View(musteriler);
        }

        // POST: Musteriler/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MusteriId,MusteriAd,Email,Adres,Telefon")] Musteriler musteriler)
        {
            if (id != musteriler.MusteriId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(musteriler);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MusterilerExists(musteriler.MusteriId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(musteriler);
        }

        // GET: Musteriler/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var musteriler = await _context.Musterilers
                .FirstOrDefaultAsync(m => m.MusteriId == id);
            if (musteriler == null)
            {
                return NotFound();
            }

            return View(musteriler);
        }

        // POST: Musteriler/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var musteriler = await _context.Musterilers.FindAsync(id);
            if (musteriler != null)
            {
                _context.Musterilers.Remove(musteriler);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MusterilerExists(int id)
        {
            return _context.Musterilers.Any(e => e.MusteriId == id);
        }
    }
}
