﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminPanel.Models;

namespace AdminPanel.Controllers
{
    public class SatisDetaylariController : Controller
    {
        private readonly _8322dbContext _context;

        public SatisDetaylariController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: SatisDetaylari
        public async Task<IActionResult> Index()
        {
            var _8322dbContext = _context.SatisDetaylaris.Include(s => s.Satis).Include(s => s.Urun);
            return View(await _8322dbContext.ToListAsync());
        }

        // GET: SatisDetaylari/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satisDetaylari = await _context.SatisDetaylaris
                .Include(s => s.Satis)
                .Include(s => s.Urun)
                .FirstOrDefaultAsync(m => m.SatisDetayId == id);
            if (satisDetaylari == null)
            {
                return NotFound();
            }

            return View(satisDetaylari);
        }

        // GET: SatisDetaylari/Create
        public IActionResult Create()
        {
            ViewData["SatisId"] = new SelectList(_context.Satislars, "SatisId", "SatisId");
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId");
            return View();
        }

        // POST: SatisDetaylari/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SatisDetayId,SatisId,UrunId,SatisBirimFiyati,SatilanMiktar,Aciklama")] SatisDetaylari satisDetaylari)
        {
            if (ModelState.IsValid)
            {
                _context.Add(satisDetaylari);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["SatisId"] = new SelectList(_context.Satislars, "SatisId", "SatisId", satisDetaylari.SatisId);
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", satisDetaylari.UrunId);
            return View(satisDetaylari);
        }

        // GET: SatisDetaylari/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satisDetaylari = await _context.SatisDetaylaris.FindAsync(id);
            if (satisDetaylari == null)
            {
                return NotFound();
            }
            ViewData["SatisId"] = new SelectList(_context.Satislars, "SatisId", "SatisId", satisDetaylari.SatisId);
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", satisDetaylari.UrunId);
            return View(satisDetaylari);
        }

        // POST: SatisDetaylari/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SatisDetayId,SatisId,UrunId,SatisBirimFiyati,SatilanMiktar,Aciklama")] SatisDetaylari satisDetaylari)
        {
            if (id != satisDetaylari.SatisDetayId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(satisDetaylari);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SatisDetaylariExists(satisDetaylari.SatisDetayId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["SatisId"] = new SelectList(_context.Satislars, "SatisId", "SatisId", satisDetaylari.SatisId);
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", satisDetaylari.UrunId);
            return View(satisDetaylari);
        }

        // GET: SatisDetaylari/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satisDetaylari = await _context.SatisDetaylaris
                .Include(s => s.Satis)
                .Include(s => s.Urun)
                .FirstOrDefaultAsync(m => m.SatisDetayId == id);
            if (satisDetaylari == null)
            {
                return NotFound();
            }

            return View(satisDetaylari);
        }

        // POST: SatisDetaylari/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var satisDetaylari = await _context.SatisDetaylaris.FindAsync(id);
            if (satisDetaylari != null)
            {
                _context.SatisDetaylaris.Remove(satisDetaylari);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SatisDetaylariExists(int id)
        {
            return _context.SatisDetaylaris.Any(e => e.SatisDetayId == id);
        }
    }
}
