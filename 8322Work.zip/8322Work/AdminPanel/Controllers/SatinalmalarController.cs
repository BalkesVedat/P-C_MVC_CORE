﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminPanel.Models;

namespace AdminPanel.Controllers
{
    public class SatinalmalarController : Controller
    {
        private readonly _8322dbContext _context;

        public SatinalmalarController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: Satinalmalar
        public async Task<IActionResult> Index()
        {
            var _8322dbContext = _context.Satinalmalars.Include(s => s.Urun);
            return View(await _8322dbContext.ToListAsync());
        }

        // GET: Satinalmalar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satinalmalar = await _context.Satinalmalars
                .Include(s => s.Urun)
                .FirstOrDefaultAsync(m => m.SatinalmaId == id);
            if (satinalmalar == null)
            {
                return NotFound();
            }

            return View(satinalmalar);
        }

        // GET: Satinalmalar/Create
        public IActionResult Create()
        {
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId");
            return View();
        }

        // POST: Satinalmalar/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SatinalmaId,SatinalmaTarihi,UrunId,AlinanMiktar,AlimBirimFiyati,Tutar,Aciklama")] Satinalmalar satinalmalar)
        {
            if (ModelState.IsValid)
            {
                _context.Add(satinalmalar);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", satinalmalar.UrunId);
            return View(satinalmalar);
        }

        // GET: Satinalmalar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satinalmalar = await _context.Satinalmalars.FindAsync(id);
            if (satinalmalar == null)
            {
                return NotFound();
            }
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", satinalmalar.UrunId);
            return View(satinalmalar);
        }

        // POST: Satinalmalar/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SatinalmaId,SatinalmaTarihi,UrunId,AlinanMiktar,AlimBirimFiyati,Tutar,Aciklama")] Satinalmalar satinalmalar)
        {
            if (id != satinalmalar.SatinalmaId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(satinalmalar);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SatinalmalarExists(satinalmalar.SatinalmaId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", satinalmalar.UrunId);
            return View(satinalmalar);
        }

        // GET: Satinalmalar/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satinalmalar = await _context.Satinalmalars
                .Include(s => s.Urun)
                .FirstOrDefaultAsync(m => m.SatinalmaId == id);
            if (satinalmalar == null)
            {
                return NotFound();
            }

            return View(satinalmalar);
        }

        // POST: Satinalmalar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var satinalmalar = await _context.Satinalmalars.FindAsync(id);
            if (satinalmalar != null)
            {
                _context.Satinalmalars.Remove(satinalmalar);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SatinalmalarExists(int id)
        {
            return _context.Satinalmalars.Any(e => e.SatinalmaId == id);
        }
    }
}
