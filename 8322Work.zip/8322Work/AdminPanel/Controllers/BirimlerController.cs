﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminPanel.Models;

namespace AdminPanel.Controllers
{
    public class BirimlerController : Controller
    {
        private readonly _8322dbContext _context;

        public BirimlerController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: Birimler
        public async Task<IActionResult> Index()
        {
            return View(await _context.Birimlers.ToListAsync());
        }

        // GET: Birimler/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var birimler = await _context.Birimlers
                .FirstOrDefaultAsync(m => m.BirimId == id);
            if (birimler == null)
            {
                return NotFound();
            }

            return View(birimler);
        }

        // GET: Birimler/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Birimler/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BirimId,BirimAd")] Birimler birimler)
        {
            if (ModelState.IsValid)
            {
                _context.Add(birimler);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(birimler);
        }

        // GET: Birimler/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var birimler = await _context.Birimlers.FindAsync(id);
            if (birimler == null)
            {
                return NotFound();
            }
            return View(birimler);
        }

        // POST: Birimler/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BirimId,BirimAd")] Birimler birimler)
        {
            if (id != birimler.BirimId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(birimler);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BirimlerExists(birimler.BirimId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(birimler);
        }

        // GET: Birimler/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var birimler = await _context.Birimlers
                .FirstOrDefaultAsync(m => m.BirimId == id);
            if (birimler == null)
            {
                return NotFound();
            }

            return View(birimler);
        }

        // POST: Birimler/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var birimler = await _context.Birimlers.FindAsync(id);
            if (birimler != null)
            {
                _context.Birimlers.Remove(birimler);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BirimlerExists(int id)
        {
            return _context.Birimlers.Any(e => e.BirimId == id);
        }
    }
}
