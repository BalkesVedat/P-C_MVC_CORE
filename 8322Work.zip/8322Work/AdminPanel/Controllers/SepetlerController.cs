﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminPanel.Models;

namespace AdminPanel.Controllers
{
    public class SepetlerController : Controller
    {
        private readonly _8322dbContext _context;

        public SepetlerController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: Sepetler
        public async Task<IActionResult> Index()
        {
            var _8322dbContext = _context.Sepetlers.Include(s => s.Musteri).Include(s => s.Urun);
            return View(await _8322dbContext.ToListAsync());
        }

        // GET: Sepetler/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sepetler = await _context.Sepetlers
                .Include(s => s.Musteri)
                .Include(s => s.Urun)
                .FirstOrDefaultAsync(m => m.SepetId == id);
            if (sepetler == null)
            {
                return NotFound();
            }

            return View(sepetler);
        }

        // GET: Sepetler/Create
        public IActionResult Create()
        {
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId");
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId");
            return View();
        }

        // POST: Sepetler/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SepetId,MusteriId,UrunId,SepetBirimFiyati,SepetUrunMiktari,SepetTarihi")] Sepetler sepetler)
        {
            if (ModelState.IsValid)
            {
                _context.Add(sepetler);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId", sepetler.MusteriId);
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", sepetler.UrunId);
            return View(sepetler);
        }

        // GET: Sepetler/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sepetler = await _context.Sepetlers.FindAsync(id);
            if (sepetler == null)
            {
                return NotFound();
            }
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId", sepetler.MusteriId);
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", sepetler.UrunId);
            return View(sepetler);
        }

        // POST: Sepetler/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SepetId,MusteriId,UrunId,SepetBirimFiyati,SepetUrunMiktari,SepetTarihi")] Sepetler sepetler)
        {
            if (id != sepetler.SepetId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(sepetler);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SepetlerExists(sepetler.SepetId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId", sepetler.MusteriId);
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", sepetler.UrunId);
            return View(sepetler);
        }

        // GET: Sepetler/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sepetler = await _context.Sepetlers
                .Include(s => s.Musteri)
                .Include(s => s.Urun)
                .FirstOrDefaultAsync(m => m.SepetId == id);
            if (sepetler == null)
            {
                return NotFound();
            }

            return View(sepetler);
        }

        // POST: Sepetler/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var sepetler = await _context.Sepetlers.FindAsync(id);
            if (sepetler != null)
            {
                _context.Sepetlers.Remove(sepetler);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SepetlerExists(int id)
        {
            return _context.Sepetlers.Any(e => e.SepetId == id);
        }
    }
}
