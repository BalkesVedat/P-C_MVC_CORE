﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminPanel.Models;

namespace AdminPanel.Controllers
{
    public class SatislarController : Controller
    {
        private readonly _8322dbContext _context;

        public SatislarController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: Satislar
        public async Task<IActionResult> Index()
        {
            var _8322dbContext = _context.Satislars.Include(s => s.Musteri);
            return View(await _8322dbContext.ToListAsync());
        }

        // GET: Satislar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satislar = await _context.Satislars
                .Include(s => s.Musteri)
                .FirstOrDefaultAsync(m => m.SatisId == id);
            if (satislar == null)
            {
                return NotFound();
            }

            return View(satislar);
        }

        // GET: Satislar/Create
        public IActionResult Create()
        {
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId");
            return View();
        }

        // POST: Satislar/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SatisId,SatisTarihi,MusteriId,Durumu,IslemTarihi,TeslimTarihi")] Satislar satislar)
        {
            if (ModelState.IsValid)
            {
                _context.Add(satislar);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId", satislar.MusteriId);
            return View(satislar);
        }

        // GET: Satislar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satislar = await _context.Satislars.FindAsync(id);
            if (satislar == null)
            {
                return NotFound();
            }
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId", satislar.MusteriId);
            return View(satislar);
        }

        // POST: Satislar/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SatisId,SatisTarihi,MusteriId,Durumu,IslemTarihi,TeslimTarihi")] Satislar satislar)
        {
            if (id != satislar.SatisId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(satislar);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SatislarExists(satislar.SatisId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MusteriId"] = new SelectList(_context.Musterilers, "MusteriId", "MusteriId", satislar.MusteriId);
            return View(satislar);
        }

        // GET: Satislar/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var satislar = await _context.Satislars
                .Include(s => s.Musteri)
                .FirstOrDefaultAsync(m => m.SatisId == id);
            if (satislar == null)
            {
                return NotFound();
            }

            return View(satislar);
        }

        // POST: Satislar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var satislar = await _context.Satislars.FindAsync(id);
            if (satislar != null)
            {
                _context.Satislars.Remove(satislar);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SatislarExists(int id)
        {
            return _context.Satislars.Any(e => e.SatisId == id);
        }
    }
}
