﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminPanel.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AdminPanel.Controllers
{
    public class ResimlerController : Controller
    {
        private readonly _8322dbContext _context;

        public ResimlerController(_8322dbContext context)
        {
            _context = context;
        }

        // GET: Resimler
        public async Task<IActionResult> Index()
        {
            var _8322dbContext = _context.Resimlers.Include(r => r.Urun);
            return View(await _8322dbContext.ToListAsync());
        }

        // GET: Resimler/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var resimler = await _context.Resimlers
                .Include(r => r.Urun)
                .FirstOrDefaultAsync(m => m.ResimId == id);
            if (resimler == null)
            {
                return NotFound();
            }

            return View(resimler);
        }

        // GET: Resimler/Create
        public IActionResult Create()
        {
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId");
            return View();
        }

        // POST: Resimler/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ResimId,UrunId,ResimYolu,ResimAciklamasi")] Resimler resimler)
        {
            if (ModelState.IsValid)
            {
                _context.Add(resimler);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", resimler.UrunId);
            return View(resimler);
        }

        // GET: Resimler/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var resimler = await _context.Resimlers.FindAsync(id);
            if (resimler == null)
            {
                return NotFound();
            }
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", resimler.UrunId);
            return View(resimler);
        }

        // POST: Resimler/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ResimId,UrunId,ResimYolu,ResimAciklamasi")] Resimler resimler)
        {
            if (id != resimler.ResimId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(resimler);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ResimlerExists(resimler.ResimId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["UrunId"] = new SelectList(_context.Urunlers, "UrunId", "UrunId", resimler.UrunId);
            return View(resimler);
        }

        // GET: Resimler/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var resimler = await _context.Resimlers
                .Include(r => r.Urun)
                .FirstOrDefaultAsync(m => m.ResimId == id);
            if (resimler == null)
            {
                return NotFound();
            }

            return View(resimler);
        }

        // POST: Resimler/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var resimler = await _context.Resimlers.FindAsync(id);
            if (resimler != null)
            {
                _context.Resimlers.Remove(resimler);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ResimlerExists(int id)
        {
            return _context.Resimlers.Any(e => e.ResimId == id);
        }
    }
}
