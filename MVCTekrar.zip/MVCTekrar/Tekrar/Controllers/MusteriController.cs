﻿using Microsoft.AspNetCore.Mvc;

namespace Tekrar.Controllers
{
    public class MusteriController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
