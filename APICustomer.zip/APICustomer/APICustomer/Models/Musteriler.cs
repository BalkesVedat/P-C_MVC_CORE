﻿using System;
using System.Collections.Generic;

namespace APICustomer.Models;

public partial class Musteriler
{
    public int MusteriId { get; set; }

    public string MusteriAd { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Adres { get; set; } = null!;

    public string Telefon { get; set; } = null!;

    public virtual ICollection<Satislar> Satislars { get; set; } = new List<Satislar>();

    public virtual ICollection<Sepetler> Sepetlers { get; set; } = new List<Sepetler>();
}
