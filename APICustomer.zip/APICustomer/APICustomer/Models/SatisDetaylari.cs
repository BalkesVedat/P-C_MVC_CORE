﻿using System;
using System.Collections.Generic;

namespace APICustomer.Models;

public partial class SatisDetaylari
{
    public int SatisDetayId { get; set; }

    public int SatisId { get; set; }

    public int UrunId { get; set; }

    public decimal SatisBirimFiyati { get; set; }

    public decimal SatilanMiktar { get; set; }

    public string? Aciklama { get; set; }

    public virtual Satislar Satis { get; set; } = null!;

    public virtual Urunler Urun { get; set; } = null!;
}
