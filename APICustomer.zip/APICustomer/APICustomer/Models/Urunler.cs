﻿using System;
using System.Collections.Generic;

namespace APICustomer.Models;

public partial class Urunler
{
    public int UrunId { get; set; }

    public string? UrunAd { get; set; }

    public decimal? BirimMaliyet { get; set; }

    public decimal? BirimFiyat { get; set; }

    public int? KategoriId { get; set; }

    public int? BirimId { get; set; }

    public string? UrunAciklamasi { get; set; }

    public virtual Birimler? Birim { get; set; }

    public virtual Kategoriler? Kategori { get; set; }

    public virtual ICollection<Resimler> Resimlers { get; set; } = new List<Resimler>();

    public virtual ICollection<Satinalmalar> Satinalmalars { get; set; } = new List<Satinalmalar>();

    public virtual ICollection<SatisDetaylari> SatisDetaylaris { get; set; } = new List<SatisDetaylari>();

    public virtual ICollection<Sepetler> Sepetlers { get; set; } = new List<Sepetler>();
}
