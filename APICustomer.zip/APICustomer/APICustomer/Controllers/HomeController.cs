using System.Diagnostics;
using APICustomer.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;

namespace APICustomer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public async Task<IActionResult> Urunler()
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage cevap = await client.GetAsync("https://localhost:7151/Urunler");

            List<Urunler>? liste = new List<Urunler>();

            if (cevap.IsSuccessStatusCode)
            {
                liste = await cevap.Content.ReadFromJsonAsync<List<Urunler>>();
            }

            return View(liste);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> MusteriKaydet()
        {
            Musteriler m1 = new Musteriler();
            //m1.MusteriId = 100;
            m1.MusteriAd = "Muhammet Enes";
            m1.Adres = "New York";
            m1.Telefon = "55555555";
            m1.Email = "enes@enes.com";
            
            HttpClient client = new HttpClient();
            HttpResponseMessage cevap = await client.PostAsJsonAsync("https://localhost:7151/api/Musteriler", m1);

            ViewBag.Mesaj = "";

            if (cevap.IsSuccessStatusCode)
            {
                ViewBag.Mesaj = "Ba�ar�l�";
            }
            else
            {
                ViewBag.Mesaj = "Hata ��kt� - " + cevap.Content.ToString();
            }

                return View();
        }
            




    }
}
